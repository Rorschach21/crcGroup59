from django.apps import AppConfig


class RentalcarConfig(AppConfig):
    name = 'RentalCar'
